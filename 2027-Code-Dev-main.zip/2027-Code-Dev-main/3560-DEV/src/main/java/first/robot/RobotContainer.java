// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package first.robot;

import org.wpilib.command3.Scheduler;
import org.wpilib.command3.button.CommandXboxController;
import org.wpilib.command3.button.RobotModeTriggers;
import org.wpilib.math.filter.SlewRateLimiter;
import first.robot.constants.DriverConstants;
import first.robot.constants.DrivetrainConstants;
import first.robot.subsystems.Drivetrain;

/**
 * Holds subsystem instances and defines the default command and button bindings for them, adapted
 * from last year's robot code (3560frc/Game-2026).
 */
public final class RobotContainer {
  public final Drivetrain drivetrain = new Drivetrain();
  private final CommandXboxController driverController =
      new CommandXboxController(DriverConstants.DRIVER_CONTROLLER_PORT);

  // Last year's drive code slewed the joystick inputs so the robot doesn't lurch when a stick is
  // slammed; the same rate is reused here for each side of the drivetrain.
  private final SlewRateLimiter leftLimiter =
      new SlewRateLimiter(DrivetrainConstants.DRIVE_SLEW_RATE);
  private final SlewRateLimiter rightLimiter =
      new SlewRateLimiter(DrivetrainConstants.DRIVE_SLEW_RATE);

  public RobotContainer() {
    configureBindings();
  }

  private void configureBindings() {
    // Tank drive on the left and right sticks, mirroring last year's layout where the driver
    // controlled each side of the drivetrain separately.
    Scheduler.getDefault()
        .setDefaultCommand(
            drivetrain,
            drivetrain.tankDriveCommand(
                () -> leftLimiter.calculate(deadband(driverController.getLeftY())),
                () -> rightLimiter.calculate(deadband(driverController.getRightY()))));

    // Disable-safe: while the robot is disabled, hold the drivetrain still.
    RobotModeTriggers.disabled().whileTrue(drivetrain.stopCommand());
  }

  /** Zeroes out small stick values so a resting joystick doesn't creep the robot. */
  private static double deadband(double input) {
    return Math.abs(input) > DrivetrainConstants.DRIVE_DEADBAND ? input : 0.0;
  }
}
